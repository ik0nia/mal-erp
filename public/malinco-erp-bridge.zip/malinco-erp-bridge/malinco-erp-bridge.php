<?php
/**
 * Plugin Name: Malinco ERP Bridge
 * Plugin URI:  https://erp.malinco.ro
 * Description: Comunicare bidirecțională între ERP Malinco și WooCommerce — meta produse, furnizori, parametri custom.
 * Version:     1.0.0
 * Author:      Malinco ERP
 * Requires WC: 5.0
 * Requires PHP: 8.1
 */

if (! defined('ABSPATH')) {
    exit;
}

define('MERP_VERSION',    '1.0.0');
define('MERP_OPTION_KEY', 'malinco_erp_api_key');
define('MERP_NS',         'malinco-erp/v1');

// ---------------------------------------------------------------------------
// REST API
// ---------------------------------------------------------------------------

add_action('rest_api_init', function () {

    // GET /version
    register_rest_route(MERP_NS, '/version', [
        'methods'             => 'GET',
        'callback'            => 'merp_get_version',
        'permission_callback' => 'merp_auth',
    ]);

    // POST /product/meta  — actualizează meta pentru un singur produs
    register_rest_route(MERP_NS, '/product/meta', [
        'methods'             => 'POST',
        'callback'            => 'merp_update_product_meta',
        'permission_callback' => 'merp_auth',
    ]);

    // POST /product/bulk-meta  — actualizare meta pentru mai multe produse
    register_rest_route(MERP_NS, '/product/bulk-meta', [
        'methods'             => 'POST',
        'callback'            => 'merp_bulk_update_meta',
        'permission_callback' => 'merp_auth',
    ]);

    // POST /self-update  — primește ZIP nou și suprascrie plugin-ul
    register_rest_route(MERP_NS, '/self-update', [
        'methods'             => 'POST',
        'callback'            => 'merp_self_update',
        'permission_callback' => 'merp_auth',
    ]);
});

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

function merp_auth(WP_REST_Request $request): bool
{
    $stored = get_option(MERP_OPTION_KEY, '');
    if ($stored === '') {
        return false;
    }

    $sent = (string) ($request->get_header('X-ERP-Api-Key') ?? '');

    return hash_equals($stored, $sent);
}

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

function merp_get_version(): WP_REST_Response
{
    return new WP_REST_Response([
        'version' => MERP_VERSION,
        'status'  => 'ok',
        'site'    => get_bloginfo('url'),
    ]);
}

function merp_update_product_meta(WP_REST_Request $request): WP_REST_Response
{
    $params = $request->get_json_params();
    $sku    = sanitize_text_field($params['sku']    ?? '');
    $wooId  = (int) ($params['woo_id'] ?? 0);
    $meta   = $params['meta'] ?? [];

    if (! is_array($meta) || empty($meta)) {
        return new WP_REST_Response(['success' => false, 'error' => 'Lipsesc câmpurile meta'], 400);
    }

    $productId = merp_resolve_product_id($wooId, $sku);

    if (! $productId) {
        return new WP_REST_Response(['success' => false, 'error' => 'Produs negăsit'], 404);
    }

    foreach ($meta as $key => $value) {
        update_post_meta($productId, sanitize_key($key), wp_unslash($value));
    }

    return new WP_REST_Response([
        'success'    => true,
        'product_id' => $productId,
        'updated'    => array_keys($meta),
    ]);
}

function merp_bulk_update_meta(WP_REST_Request $request): WP_REST_Response
{
    $params  = $request->get_json_params();
    $items   = $params['items'] ?? [];

    if (! is_array($items)) {
        return new WP_REST_Response(['success' => false, 'error' => 'Format invalid'], 400);
    }

    $results = ['updated' => 0, 'failed' => 0, 'errors' => []];

    foreach ($items as $item) {
        $sku   = sanitize_text_field($item['sku']    ?? '');
        $wooId = (int) ($item['woo_id'] ?? 0);
        $meta  = $item['meta'] ?? [];

        $productId = merp_resolve_product_id($wooId, $sku);

        if (! $productId) {
            $results['failed']++;
            $results['errors'][] = ['sku' => $sku, 'woo_id' => $wooId, 'error' => 'Negăsit'];
            continue;
        }

        foreach ($meta as $key => $value) {
            update_post_meta($productId, sanitize_key($key), wp_unslash($value));
        }

        $results['updated']++;
    }

    return new WP_REST_Response(['success' => true, 'results' => $results]);
}

function merp_self_update(WP_REST_Request $request): WP_REST_Response
{
    $files = $request->get_file_params();

    if (empty($files['plugin']) || $files['plugin']['error'] !== UPLOAD_ERR_OK) {
        return new WP_REST_Response(['success' => false, 'error' => 'Fișier lipsă sau eroare upload'], 400);
    }

    $tmpFile  = $files['plugin']['tmp_name'];
    $mimeType = mime_content_type($tmpFile);

    if (! in_array($mimeType, ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'], true)) {
        return new WP_REST_Response(['success' => false, 'error' => 'Nu este un fișier ZIP valid'], 400);
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    WP_Filesystem();

    $result = unzip_file($tmpFile, WP_PLUGIN_DIR);

    if (is_wp_error($result)) {
        return new WP_REST_Response(['success' => false, 'error' => $result->get_error_message()], 500);
    }

    return new WP_REST_Response(['success' => true, 'message' => 'Plugin actualizat cu succes']);
}

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

function merp_resolve_product_id(int $wooId, string $sku): int
{
    if ($wooId > 0 && get_post($wooId)) {
        return $wooId;
    }

    if ($sku !== '') {
        $id = wc_get_product_id_by_sku($sku);
        return $id ?: 0;
    }

    return 0;
}

// ---------------------------------------------------------------------------
// Admin Settings Page
// ---------------------------------------------------------------------------

add_action('admin_menu', function () {
    add_options_page(
        'Malinco ERP Bridge',
        'ERP Bridge',
        'manage_options',
        'malinco-erp-bridge',
        'merp_settings_page'
    );
});

function merp_settings_page(): void
{
    if (! current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['merp_save'])) {
        check_admin_referer('merp_settings');
        $newKey = sanitize_text_field($_POST['merp_api_key'] ?? '');
        if ($newKey !== '') {
            update_option(MERP_OPTION_KEY, $newKey);
            echo '<div class="notice notice-success"><p>Setări salvate.</p></div>';
        }
    }

    $currentKey = get_option(MERP_OPTION_KEY, '');
    ?>
    <div class="wrap">
        <h1>Malinco ERP Bridge <span style="font-size:0.6em;background:#eee;padding:2px 8px;border-radius:4px;">v<?php echo esc_html(MERP_VERSION); ?></span></h1>

        <form method="post">
            <?php wp_nonce_field('merp_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="merp_api_key">API Key (secret)</label></th>
                    <td>
                        <input type="text" id="merp_api_key" name="merp_api_key"
                               value="<?php echo esc_attr($currentKey); ?>" class="regular-text" />
                        <p class="description">Trebuie să coincidă cu <code>WOO_PLUGIN_API_KEY</code> din ERP → Setări aplicație.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Salvează', 'primary', 'merp_save'); ?>
        </form>

        <hr>
        <h2>Endpoint-uri disponibile</h2>
        <p>Base URL: <code><?php echo esc_html(rest_url(MERP_NS . '/')); ?></code></p>
        <table class="widefat" style="max-width:700px;">
            <thead><tr><th>Metodă</th><th>Endpoint</th><th>Descriere</th></tr></thead>
            <tbody>
                <tr><td><code>GET</code></td><td><code>/version</code></td><td>Versiune plugin + status</td></tr>
                <tr><td><code>POST</code></td><td><code>/product/meta</code></td><td>Actualizează meta unui produs (SKU sau woo_id)</td></tr>
                <tr><td><code>POST</code></td><td><code>/product/bulk-meta</code></td><td>Actualizare meta pentru mai multe produse</td></tr>
                <tr><td><code>POST</code></td><td><code>/self-update</code></td><td>Actualizare plugin din ERP (upload ZIP)</td></tr>
            </tbody>
        </table>
        <p style="margin-top:12px;">Autentificare: header <code>X-ERP-Api-Key: {cheia_ta}</code></p>
    </div>
    <?php
}
